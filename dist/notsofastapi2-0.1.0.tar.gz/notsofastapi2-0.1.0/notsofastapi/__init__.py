# notsofastapi/__init__.py
from .main import NotSoFastAPI

__version__ = "0.1.0"
__author__ = "Aniket Surjuse"
__email__ = "asurjuse111@gmail.com"


